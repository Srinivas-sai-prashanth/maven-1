package com.sahni.todoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToDoAPI {
    public static void main(String[] args) {
        SpringApplication.run(ToDoAPI.class, args);
    }
}
