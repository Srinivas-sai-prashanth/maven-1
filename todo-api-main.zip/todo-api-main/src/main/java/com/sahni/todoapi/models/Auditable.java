package com.sahni.todoapi.models;

public class Auditable {
}
